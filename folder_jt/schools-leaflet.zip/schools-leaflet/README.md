# Skool Picker - Group6
- Download and convert csv + shp files to geoJson
- Using mapBox to create map layer
- Data markers should be clustered and gives school information when clicked
- Create heatmap of median house prices around school area
- Create heatmap of median income around school area
