// API key
const API_KEY = "pk.eyJ1IjoiamFzb250eWgiLCJhIjoiY2sxZG4wZHpsMDN4ZzNobXo5MWYzb3NkNiJ9.1yzHHrYcOhfXXaPcNS930Q";
